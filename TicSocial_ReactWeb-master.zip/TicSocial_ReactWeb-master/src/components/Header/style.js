import styled from 'styled-components';

export const BarraNav = styled.div`
    
    svg{
        margin-right: 6px;
        width: 50px;
        height: 30px;

    #btnGer {
        color: #01FF00;
    }
    }
`

export const BotaoNav = styled.span`    

    button{
        display: block-inline;
        margin: 0 10px 0 15px;
        background-color: green;
        color:  #fff;
        border-radius: 8px;
        border: 1px solid;
        border-color: #fff;

        &:hover{
            background-color: #fff;
            color: #01FF00;
            transition: 0.5s;
        }

    }

    svg{
        margin-left: 8px; 
    }
`;