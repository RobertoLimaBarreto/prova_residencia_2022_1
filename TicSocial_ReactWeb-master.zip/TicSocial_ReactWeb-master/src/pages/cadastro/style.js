
import styled from 'styled-components';

export const Conteudo = styled.div`
    background-color: #fff;

    width: 500px;
    margin-left: -100px;
    display: flex;
    place-items: center;

    form {
        background-color: #fff;
        margin-top: 100px;
        padding: 30px;
        border-radius: 10px;
        align-items:center;
        opacity: 0.9;
    }

    form input {
        background-color: #343A40;
        width: 100%;
        margin: 10px 0;
        border-radius: 8px;
        margin-bottom: 10px;
        border-bottom: 1px solid #343A40;
        padding: 6px;
        color: #c5e989;

        &:hover,
        &:focus{
            outline: none;
            background-color: #343A40;
            opacity: 0.7;
            color: #fff;  
            border-radius: 8px;
        }    

        &::placeholder{
            color: #cdcdcd;
        }
    }

    form label{
        text-align: center;
        font-weight: bold;
        color: #343A40;
        width: 1000px;
    }

    form button{
        width: 100%;
        height: 30px;
        background-color: #3ec300;
        color: #fff;
        border: 0;
        border-radius: 6px;
        transition: 0.2s;
        box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
        text-align: center;
        margin: 10px 0;
        padding: 5px;
        font-size: 16px;
        font-weight: bold;

        &:hover{
            background-color: #46d900;
            color: #fafafa;
        }
}
  
`;




