import React from 'react';
import { Conteudo } from './style'
import { useHistory } from 'react-router-dom';


const Controle = () => {
    const history = useHistory();

    return (
        <Conteudo>
            <div>
                <button  onClick={e => history.push("controle/funcionario")}>Funcionario</button >
                <button  onClick={e => history.push("controle/produto")}>Produto</button >
            </div>
           
            <div> 
                <button  onClick={e => history.push("controle/Categoria")}>Categoria</button >
                <button  onClick={e => history.push("controle/Cliente")}>Cliente</button >
            </div>
        </Conteudo>
    )
}
export default Controle;
